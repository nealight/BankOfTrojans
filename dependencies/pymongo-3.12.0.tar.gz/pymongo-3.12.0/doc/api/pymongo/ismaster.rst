:orphan:

:mod:`ismaster` -- **DEPRECATED** A wrapper for hello command responses.
========================================================================

.. automodule:: pymongo.ismaster

   .. autoclass:: pymongo.ismaster.IsMaster(doc)

      .. autoattribute:: document
