:mod:`server_api` -- Support for MongoDB Versioned API
======================================================

.. automodule:: pymongo.server_api
   :synopsis: Support for MongoDB Versioned API

   .. autoclass:: pymongo.server_api.ServerApi
      :members:

   .. autoclass:: pymongo.server_api.ServerApiVersion
      :members:
