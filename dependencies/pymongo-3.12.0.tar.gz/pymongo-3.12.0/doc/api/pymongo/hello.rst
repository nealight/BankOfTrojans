:orphan:

:mod:`hello` -- A wrapper for hello command responses.
======================================================

.. automodule:: pymongo.hello

   .. autoclass:: pymongo.hello.Hello(doc)

      .. autoattribute:: document
